@FunctionalInterface
public interface Operacion {
    
    double calcular(double n1,double n2);
    //Interface funcional solamente tiene un sólo método 
    //void saludar();
}
