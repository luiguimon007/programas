@FunctionalInterface
public interface IPersona {
    Persona crear(int id,String nombre);
}
