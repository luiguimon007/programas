@FunctionalInterface
public interface OperacionB {
    void saludar();
}
