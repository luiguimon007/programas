var clase = Java.type('java.util.ArrayList');
var lista = new clase();
lista.add('MitoCode');
lista.add('Mito');
lista.add('Code');

print(lista.get(2));