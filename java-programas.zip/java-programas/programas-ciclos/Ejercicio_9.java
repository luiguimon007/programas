public class Ejercicio_9 {
    public static void main(String[] args) {
        for (int i = 100; i > 0; i-=7){
            System.out.println("NUM "+i);
        }
    }
}
